package com.example.liengofflinetool

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.app.AlertDialog
import kotlin.math.abs

class FloatingMenuService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams
    private var cards = mutableListOf<String>()
    private var callAmount = 100
    private var opponents = 2
    private lateinit var result: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) createPanel()
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        params = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(100) }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(10))
            setBackgroundColor(Color.rgb(247, 250, 248))
        }
        val header = TextView(this).apply {
            text = "☰ LIÊNG TOOL   •   chạm giữ để kéo"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setBackgroundColor(Color.rgb(24, 92, 67))
        }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = ox + (e.rawX - sx).toInt()
                        params.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(box, params); return true
                    }
                }
                return true
            }
        })
        val select = Button(this).apply { text = "Chọn 3 lá bài của bạn" }
        val bet = Button(this).apply { text = "Tiền cần theo: 100" }
        val opp = Button(this).apply { text = "Đối thủ còn lại: 2" }
        val analyze = Button(this).apply { text = "Phân tích nên theo / bỏ" }
        result = TextView(this).apply {
            text = "Chưa có dữ liệu. Chọn 3 lá trước."
            textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(8), 0, dp(8))
        }
        val close = Button(this).apply { text = "Thu gọn / đóng menu" }
        select.setOnClickListener { chooseCards() }
        bet.setOnClickListener {
            val input = EditText(this).apply { inputType = 2; setText(callAmount.toString()); hint = "Số tiền cần theo" }
            AlertDialog.Builder(this).setTitle("Tiền cần theo (đơn vị tùy chọn)")
                .setView(input).setPositiveButton("Lưu") { _, _ ->
                    callAmount = input.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 100
                    bet.text = "Tiền cần theo: $callAmount"
                }.setNegativeButton("Hủy", null).show()
        }
        opp.setOnClickListener {
            val options = arrayOf("1", "2", "3", "4", "5")
            AlertDialog.Builder(this).setTitle("Đối thủ còn lại")
                .setItems(options) { _, which ->
                    opponents = options[which].toInt()
                    opp.text = "Đối thủ còn lại: $opponents"
                }.show()
        }
        analyze.setOnClickListener { analyzeHand() }
        close.setOnClickListener { stopSelf() }
        listOf(header, select, bet, opp, analyze, result, close).forEach { box.addView(it) }
        panel = box
        wm.addView(box, params)
    }

    private fun chooseCards() {
        val ranks = listOf("2","3","4","5","6","7","8","9","10","J","Q","K","A")
        val suits = listOf("♠","♥","♦","♣")
        val deck = ranks.flatMap { r -> suits.map { s -> "$r$s" } }.toTypedArray()
        val selected = BooleanArray(52) { i -> deck[i] in cards }
        AlertDialog.Builder(this)
            .setTitle("Chọn đúng 3 lá bài của bạn")
            .setMultiChoiceItems(deck, selected) { _, which, checked ->
                if (checked && cards.size < 3) cards.add(deck[which])
                else if (checked) Toast.makeText(this, "Chỉ chọn 3 lá", Toast.LENGTH_SHORT).show()
                else cards.remove(deck[which])
            }
            .setPositiveButton("Xong") { _, _ ->
                if (cards.size > 3) cards = cards.take(3).toMutableList()
                result.text = if (cards.size == 3) "Bài đã chọn: ${cards.joinToString(" ")}" else "Bạn cần chọn đúng 3 lá."
            }.setNegativeButton("Hủy", null).show()
    }

    private fun rank(card: String) = when (card.dropLast(1)) {
        "A" -> 14; "K" -> 13; "Q" -> 12; "J" -> 11; "10" -> 10
        else -> card.dropLast(1).toIntOrNull() ?: 0
    }

    private fun analyzeHand() {
        if (cards.size != 3) {
            result.text = "Hãy chọn đủ 3 lá bài trước."
            return
        }
        val rs = cards.map { rank(it) }.sortedDescending()
        val sameRank = rs.distinct().size == 1
        val counts = rs.groupingBy { it }.eachCount()
        val pair = counts.values.any { it == 2 }
        val flush = cards.map { it.last() }.distinct().size == 1
        val straight = rs[0] - rs[1] == 1 && rs[1] - rs[2] == 1
        val score = when {
            sameRank -> 100
            straight && flush -> 90
            flush -> 75
            straight -> 70
            pair -> 55
            else -> (rs.sum() * 1.0 / 42.0 * 40).toInt().coerceIn(1, 40)
        }
        val label = when {
            sameRank -> "Sáp / bộ ba"
            straight && flush -> "Sảnh đồng chất"
            flush -> "Đồng chất"
            straight -> "Sảnh"
            pair -> "Đôi"
            else -> "Bài lẻ"
        }
        val threshold = when {
            opponents >= 4 -> 68
            opponents == 3 -> 58
            else -> 48
        } + (callAmount / 1000).coerceAtMost(20)
        val advice = when {
            score >= threshold + 20 -> "NÊN THEO"
            score >= threshold -> "CÂN NHẮC"
            else -> "NÊN BỎ"
        }
        result.text = "$label • điểm tham khảo $score/100\nGợi ý: $advice\nĐối thủ: $opponents • tiền theo: $callAmount\nĐây là heuristic đơn giản, chưa phải xác suất thắng thật; không biết bài úp của AI."
    }

    override fun onDestroy() {
        if (panel != null) { try { wm.removeView(panel) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}

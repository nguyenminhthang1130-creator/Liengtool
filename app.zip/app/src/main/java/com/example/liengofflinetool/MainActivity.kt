package com.example.liengofflinetool

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(245, 247, 246))
        }
        val title = TextView(this).apply {
            text = "Liêng Offline Tool"
            textSize = 25f
            setTextColor(Color.rgb(24, 65, 51))
        }
        val info = TextView(this).apply {
            text = "Menu nổi kéo thả • Nhập 3 lá bài • Ước tính theo/bỏ\n\nTool không nhìn được bài úp của AI. Gợi ý chỉ mang tính tham khảo."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 20, 0, 24)
        }
        val grant = Button(this).apply { text = "Cấp quyền menu nổi" }
        val start = Button(this).apply { text = "Mở menu nổi" }
        root.addView(title)
        root.addView(info)
        root.addView(grant)
        root.addView(start)
        setContentView(root)

        grant.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingMenuService::class.java))
                finish()
            } else {
                grant.performClick()
            }
        }
    }
}
